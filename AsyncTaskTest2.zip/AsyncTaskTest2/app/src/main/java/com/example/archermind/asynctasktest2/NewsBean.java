package com.example.archermind.asynctasktest2;

/**
 * Created by archermind on 12/24/18.
 * Wzj
 * content
 */

public class NewsBean {

    public String newsIconUrl;
    public String newsTitle;
    public String newsContent;


}
