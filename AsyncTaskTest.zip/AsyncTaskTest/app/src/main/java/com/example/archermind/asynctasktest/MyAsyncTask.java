package com.example.archermind.asynctasktest;

import android.os.AsyncTask;
import android.util.Log;

/**
 * Created by archermind on 12/21/18.
 * Wzj
 * content
 * 异步处理，下载图像
 * UI线程，设置图像
 */

/**
 * Void 表示空类型
 * 2
 */

public class MyAsyncTask extends AsyncTask<Void,Void,Void> {
    @Override
    protected Void doInBackground(Void... voids) {
        Log.e("wzj", "doInBackground: ");
        publishProgress(); //在doInBackground方法中調用publishProgress方法，更新任务的执行进度，就会触发onProgressUpdate方法_——————————传递进度值
        return null;
    }


    /**
     * 1
     */
    @Override
    protected void onPreExecute() {
        Log.e("wzj", "onPreExecute: ");
        super.onPreExecute();
    }


    /**
     * 4
     * @param aVoid
     */
    @Override
    protected void onPostExecute(Void aVoid) {
        Log.e("wzj", "onPostExecute: ");
        super.onPostExecute(aVoid);
    }

    /**
     * 3
     * @param values
     * 获取进度，更新进度条
     */
    @Override
    protected void onProgressUpdate(Void... values) {
        Log.e("wzj", "onProgressUpdate: ");
        super.onProgressUpdate(values);
    }
}
