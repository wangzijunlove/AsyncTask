package com.example.archermind.asynctasktest;

import android.app.Activity;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.AsyncTask;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.ProgressBar;

import java.io.BufferedInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.URL;
import java.net.URLConnection;

public class ImageTest extends Activity {

    private ImageView mImageView;
    private ProgressBar mProgressBar;
    private static String URL = "http://img.my.csdn.net/uploads/201504/12/1428806103_9476.png";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_image_test);
        mImageView = findViewById(R.id.image);
        mProgressBar = findViewById(R.id.pb);
        //设置传递进去的参数
        new MyAsyncTask().execute(URL);
    }

    /**
     * URL类型，进度值类型，返回值类型
     */
    class MyAsyncTask extends AsyncTask<String, Void, Bitmap>{

        //加载进度条
        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            mProgressBar.setVisibility(View.VISIBLE); // 显示进度条
        }

        /**
         * 显示图片
         * 操作UI
         * @param bitmap
         */
        @Override
        protected void onPostExecute(Bitmap bitmap) {
            super.onPostExecute(bitmap);
            mProgressBar.setVisibility(View.GONE);
            mImageView.setImageBitmap(bitmap); //设置图像

        }


        /**
         * 下载网络数据
         * 不定长数组，因为只传递一个数，所以用params[0]
         * @param params
         * @return
         */
        @Override
        protected Bitmap doInBackground(String... params) {
            //获取传递进来的参数
            String url = params[0]; //取出对应的url
            Bitmap bitmap = null;
            URLConnection connection; //定义网络连接对象
            InputStream is; //用于获取数据的输入流

            try {
                connection = new URL(url).openConnection(); //获取网络连接对象
                is = connection.getInputStream(); //获取输入流
                BufferedInputStream bis = new BufferedInputStream(is);
                Thread.sleep(3000);
                //通过decodeStream解析输入流
                bitmap = BitmapFactory.decodeStream(bis); //将输入流解析成bitmap
                is.close();
                bis.close();
            } catch (IOException e) {
                e.printStackTrace();
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
            //将bitmap作为返回值
            return bitmap;
        }
    }
}
