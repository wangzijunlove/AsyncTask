package com.example.archermind.asysnctask;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.AsyncTask;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.Toast;

import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.DefaultHttpClient;

import java.io.IOException;

public class MainActivity extends AppCompatActivity {

    private final static String IMAGE_PATH = "http://oschina.net/img/logo.gif";
    private ImageView imageView;
    private Button button1;
    private Button button2;
    private ProgressBar progressBar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        imageView = findViewById(R.id.imageView);
        button1 = findViewById(R.id.button);
        button2 = findViewById(R.id.button2);
        progressBar = findViewById(R.id.processBar);

        button1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                MyTask myTask = new MyTask();
                myTask.execute(IMAGE_PATH);
                
            }
        });

        button2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                MyTask myTask = new MyTask();
                myTask.cancel(true);
            }
        });
    }

    /**
     * 继承AsyncTask
      */
    class MyTask extends AsyncTask<String, Integer, Bitmap> {

        //准备运行---该回调方法在任务被执行之后立即由线程调用。这个步骤通常用来建立任务，在UI上显示进度条。
        @Override
        protected void onPreExecute() {
            imageView.setImageBitmap(null);//每次在准备阶段先清除掉设置的图片
            progressBar.setProgress(0);//进度条初始值为0
        }

        /**
         * 正在后台运行
         * 该回调方法由后台线程在onPreExecute（）方法结束后立刻调用
         * 通常在这里执行耗时的后台计算，计算的结果必须由该函数返回，并被传到onPostExecute()中。
         * 在该方法内也可使用publishProcess()来发布一个或多个进度单位，这些值将会在onProgressUpdate()中被发布到UI线程。
         * @param strings
         * @return
         */
        @Override
        protected Bitmap doInBackground(String... strings) {
            //发布进度单位，系统将会调用onProcessUpdate()方法更新这些值
            publishProgress(0);//进度值0

            final Bitmap bitmap;
            HttpClient httpClient = new DefaultHttpClient();

            //获取网站图片
            HttpGet httpGet = new HttpGet(strings[0]);
            publishProgress(30);


            try {
                HttpResponse httpResponse = httpClient.execute(httpGet);
                publishProgress(70);
                bitmap = BitmapFactory.decodeStream(httpResponse.getEntity().getContent());
            } catch (IOException e) {
                return null;
            }

            publishProgress(100);
            return bitmap;

        }

        /**
         * 进度更新---该方法由UI线程在publishProgress()方法调用完后被调用，一般用于动态地显示一个进度条。
         * @param values
         */
        @Override
        protected void onProgressUpdate(Integer... values) {
            //更新进度条的进度
            progressBar.setProgress(values[0]);
        }

        /**
         * 完成后台任务---后台任务执行之后被调用，在UI线程执行
         * @param bitmap
         */
        @Override
        protected void onPostExecute(Bitmap bitmap) {
            if(bitmap != null){
                Toast.makeText(MainActivity.this,"获取图片成功",Toast.LENGTH_LONG).show();
                imageView.setImageBitmap(bitmap);
            }else {
                Toast.makeText(MainActivity.this,"获取图片失败",Toast.LENGTH_LONG).show();
            }
        }

        /**
         * 取消任务
         */
        // 在调用AsyncTask的cancel()方法时调用，在UI线程执行。
        @Override
        protected void onCancelled() {
            progressBar.setProgress(0);// 进度条复位
//            imageView.setImageDrawable(getResources().getDrawable(
//                    R.drawable.ic_launcher_background));
            imageView.setImageBitmap(null);
            Toast.makeText(MainActivity.this, "取消从网络获取的图片",
                    Toast.LENGTH_LONG).show();
        }
    }

}
